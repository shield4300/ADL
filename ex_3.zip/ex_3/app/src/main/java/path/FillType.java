package path;

public class FillType {
}
