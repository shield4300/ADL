package com.example.exp_51;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
public class MainActivity extends AppCompatActivity
{
    Button bt1,bt2,bt3;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = (Button) findViewById(R.id.button3);
        bt2 = (Button) findViewById(R.id.button4);
        bt3 = (Button) findViewById(R.id.CLick);



        bt3.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
                new Thread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        bt1.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                bt1.setText("CDE");
                            }
                        });
                        bt2.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                bt2.setText("CDE");
                            }
                        });
                    }
                }).start();
            }
        });
    }}