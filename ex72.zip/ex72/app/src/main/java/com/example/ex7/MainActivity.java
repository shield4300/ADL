package com.example.ex7;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.*;
import java.io.*;
public class MainActivity extends AppCompatActivity {
    EditText edit;
    Button write, read, clear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit = (EditText) findViewById(R.id.editText);
        write = (Button) findViewById(R.id.write);
        read = (Button) findViewById(R.id.read);
        clear = (Button) findViewById(R.id.clear);
        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = edit.getText().toString();
                try {
                    File folder = null;
                    if (android.os.Build.VERSION.SDK_INT >=
                            android.os.Build.VERSION_CODES.KITKAT) {
                        folder =
                                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS
                                );
                    }
                    File f = new File(folder, "myfile.txt");
                    f.createNewFile();
                    FileOutputStream fos = new FileOutputStream(f);
                    OutputStreamWriter osw = new OutputStreamWriter(fos);
                    osw.append(message);
                    osw.close();
                    fos.close();
                    Toast.makeText(getBaseContext(), "Data written to SD card",
                            Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message;
                String buf = "";
                try {
                    File folder = null;
                    if (android.os.Build.VERSION.SDK_INT >=
                            android.os.Build.VERSION_CODES.KITKAT) {
                        folder =
                                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS
                                );
                    }
                    File f = new File(folder, "myfile.txt");
                    FileInputStream fin = new FileInputStream(f);
                    BufferedReader br = new BufferedReader(new InputStreamReader(fin));
                    while((message = br.readLine()) != null){
                        buf += message;
                    }
                    edit.setText(buf);
                    br.close();
                    fin.close();
                    Toast.makeText(getBaseContext(), "Data read from SD card",
                            Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit.setText("");
            }
        });
    }
}
